// ПЕРЕДАВАЧ (маяк). Прошийте однаково на всі 3 ESP32.
// Кожні ~100 мс надсилає широкомовний пакет ESP-NOW. Приймач дізнається MAC
// відправника з самого пакета і вимірює силу сигналу.
// Потрібне ядро Arduino-ESP32 версії 3.x.

#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi.h>

const uint8_t  CHANNEL     = 1;    // однаковий на всіх пристроях
const uint32_t INTERVAL_MS = 100;  // як часто надсилати пакет
const uint8_t  BROADCAST[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

struct __attribute__((packed)) Beacon { uint32_t magic; uint32_t seq; };
const uint32_t MAGIC = 0x4C4F4331;  // «LOC1» — щоб приймач ігнорував чужі пакети

uint32_t seq = 0;
unsigned long lastInfo = 0;

void setup() {
  Serial.begin(115200);
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  esp_wifi_set_channel(CHANNEL, WIFI_SECOND_CHAN_NONE);
  esp_wifi_set_max_tx_power(78);  // фіксована потужність (19,5 дБм), щоб сила була стабільною

  if (esp_now_init() != ESP_OK) { Serial.println("Помилка ESP-NOW"); delay(1000); ESP.restart(); }

  esp_now_peer_info_t peer = {};
  memcpy(peer.peer_addr, BROADCAST, 6);
  peer.channel = CHANNEL;
  peer.encrypt = false;
  esp_now_add_peer(&peer);
}

void loop() {
  Beacon b{MAGIC, seq++};
  esp_now_send(BROADCAST, (const uint8_t*)&b, sizeof(b));

  if (millis() - lastInfo > 3000) {  // MAC потрібен для реєстрації на Raspberry Pi
    lastInfo = millis();
    Serial.print("MAC цього передавача: ");
    Serial.println(WiFi.macAddress());
  }
  delay(INTERVAL_MS + random(0, 20));  // невеликий розкид, щоб пакети не збігалися
}
