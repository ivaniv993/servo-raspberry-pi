// ПРИЙМАЧ. Отримує пакети від передавачів, вимірює силу сигналу і
// надсилає на Raspberry Pi рядки:  24:6F:28:A1:00:01, 640;
// Дані йдуть одночасно в USB (Serial) і в UART (Serial2) — використовуйте будь-яке підключення.
// Потрібне ядро Arduino-ESP32 версії 3.x.

#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi.h>

const uint8_t CHANNEL = 1;          // той самий, що на передавачах

// Перетворення RSSI (дБм) у шкалу 0–1000
const int RSSI_MIN = -100;          // -> 0
const int RSSI_MAX = -30;           // -> 1000

// UART до Raspberry Pi (якщо не через USB)
const int PI_TX_PIN = 17;           // ESP32 GPIO17 -> Pi GPIO15 (RXD, пін 10)
const int PI_RX_PIN = 16;           // ESP32 GPIO16 <- Pi GPIO14 (TXD, пін 8)

struct __attribute__((packed)) Beacon { uint32_t magic; uint32_t seq; };
const uint32_t MAGIC = 0x4C4F4331;

struct Msg { uint8_t mac[6]; int8_t rssi; };
QueueHandle_t queue;

// Викликається в задачі Wi-Fi: тут лише кладемо дані в чергу, друкуємо в loop()
void onReceive(const esp_now_recv_info_t* info, const uint8_t* data, int len) {
  if (len != sizeof(Beacon)) return;
  Beacon b;
  memcpy(&b, data, sizeof(b));
  if (b.magic != MAGIC) return;
  Msg m;
  memcpy(m.mac, info->src_addr, 6);
  m.rssi = info->rx_ctrl->rssi;
  xQueueSend(queue, &m, 0);
}

void setup() {
  Serial.begin(115200);
  Serial2.begin(115200, SERIAL_8N1, PI_RX_PIN, PI_TX_PIN);
  queue = xQueueCreate(64, sizeof(Msg));

  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  esp_wifi_set_channel(CHANNEL, WIFI_SECOND_CHAN_NONE);

  if (esp_now_init() != ESP_OK) { delay(1000); ESP.restart(); }
  esp_now_register_recv_cb(onReceive);
}

void loop() {
  Msg m;
  while (xQueueReceive(queue, &m, pdMS_TO_TICKS(10)) == pdTRUE) {
    int s = constrain(map(m.rssi, RSSI_MIN, RSSI_MAX, 0, 1000), 0, 1000);
    char line[40];
    snprintf(line, sizeof(line), "%02X:%02X:%02X:%02X:%02X:%02X, %d;\n",
             m.mac[0], m.mac[1], m.mac[2], m.mac[3], m.mac[4], m.mac[5], s);
    Serial.print(line);
    Serial2.print(line);
  }
}
