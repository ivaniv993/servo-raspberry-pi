// ПРИЙМАЧ. Слухає ефір і вимірює силу сигналу БУДЬ-ЯКОГО передавача на каналі.
// Реєстрація на приймачі не потрібна: він передає на Raspberry Pi усе, що чує.
// Раз на 200 мс надсилає середню силу для кожного MAC:
//   24:6F:28:A1:00:01, 640;
// Дані йдуть одночасно в USB (Serial) і в UART (Serial2).
// Потрібне ядро Arduino-ESP32 версії 3.x.

#include <WiFi.h>
#include <esp_wifi.h>

// Що слухати:
//   LISTEN_ESPNOW   — будь-які ESP32, що надсилають ESP-NOW (з будь-якою прошивкою)
//   LISTEN_ALL_WIFI — будь-які пристрої Wi-Fi на цьому каналі (роутери, телефони, ESP32)
enum ListenMode { LISTEN_ESPNOW, LISTEN_ALL_WIFI };
const ListenMode MODE = LISTEN_ESPNOW;

const uint8_t  CHANNEL   = 1;      // той самий, що на передавачах
const uint32_t REPORT_MS = 200;    // як часто надсилати дані на Pi

// Перетворення RSSI (дБм) у шкалу 0–1000
const float RSSI_MIN = -100;       // -> 0
const float RSSI_MAX = -30;        // -> 1000

// UART до Raspberry Pi (якщо не через USB)
const int PI_TX_PIN = 17;          // ESP32 GPIO17 -> Pi GPIO15 (RXD, пін 10)
const int PI_RX_PIN = 16;          // ESP32 GPIO16 <- Pi GPIO14 (TXD, пін 8)

struct Msg { uint8_t mac[6]; int8_t rssi; };
QueueHandle_t queue;

// Викликається для кожного кадру в ефірі. Тут лише фільтруємо і кладемо в чергу.
void sniffer(void* buf, wifi_promiscuous_pkt_type_t type) {
  if (type != WIFI_PKT_MGMT && type != WIFI_PKT_DATA) return;
  const wifi_promiscuous_pkt_t* pkt = (const wifi_promiscuous_pkt_t*)buf;
  const uint8_t* p = pkt->payload;
  int len = pkt->rx_ctrl.sig_len;
  if (len < 24) return;

  if (MODE == LISTEN_ESPNOW) {
    // ESP-NOW: кадр Action (0xD0), категорія 127, ідентифікатор Espressif 18:FE:34
    if (len < 28 || p[0] != 0xD0 || p[24] != 0x7F ||
        p[25] != 0x18 || p[26] != 0xFE || p[27] != 0x34) return;
  }

  const uint8_t* src = p + 10;          // адреса відправника кадру
  if (src[0] & 0x01) return;            // групова адреса — не справжній пристрій

  Msg m;
  memcpy(m.mac, src, 6);
  m.rssi = pkt->rx_ctrl.rssi;
  xQueueSend(queue, &m, 0);
}

// ---------- Накопичення вимірів по кожному MAC ----------
struct Entry { uint8_t mac[6]; int32_t sum; uint16_t count; uint32_t lastSeen; bool used; };
const int MAX_ENTRIES = 64;
Entry table[MAX_ENTRIES];

void addSample(const Msg& m) {
  int freeIdx = -1, oldest = 0;
  for (int i = 0; i < MAX_ENTRIES; i++) {
    if (table[i].used && memcmp(table[i].mac, m.mac, 6) == 0) {
      table[i].sum += m.rssi; table[i].count++; table[i].lastSeen = millis();
      return;
    }
    if (!table[i].used && freeIdx < 0) freeIdx = i;
    if (table[i].used && table[i].lastSeen < table[oldest].lastSeen) oldest = i;
  }
  int i = freeIdx >= 0 ? freeIdx : oldest;   // таблиця повна — витісняємо найдавніший
  memcpy(table[i].mac, m.mac, 6);
  table[i].sum = m.rssi; table[i].count = 1; table[i].lastSeen = millis(); table[i].used = true;
}

void report() {
  uint32_t now = millis();
  for (int i = 0; i < MAX_ENTRIES; i++) {
    Entry& e = table[i];
    if (!e.used) continue;
    if (e.count > 0) {
      float rssi = (float)e.sum / e.count;
      int s = (int)constrain((rssi - RSSI_MIN) * 1000.0f / (RSSI_MAX - RSSI_MIN), 0.0f, 1000.0f);
      char line[40];
      snprintf(line, sizeof(line), "%02X:%02X:%02X:%02X:%02X:%02X, %d;\n",
               e.mac[0], e.mac[1], e.mac[2], e.mac[3], e.mac[4], e.mac[5], s);
      Serial.print(line);
      Serial2.print(line);
      e.sum = 0; e.count = 0;
    } else if (now - e.lastSeen > 10000) {
      e.used = false;                          // пристрій зник — звільняємо місце
    }
  }
}

uint32_t lastReport = 0;

void setup() {
  Serial.begin(115200);
  Serial2.begin(115200, SERIAL_8N1, PI_RX_PIN, PI_TX_PIN);
  queue = xQueueCreate(256, sizeof(Msg));

  WiFi.mode(WIFI_STA);
  WiFi.disconnect();

  wifi_promiscuous_filter_t filter;
  filter.filter_mask = WIFI_PROMIS_FILTER_MASK_MGMT | WIFI_PROMIS_FILTER_MASK_DATA;
  esp_wifi_set_promiscuous_filter(&filter);
  esp_wifi_set_promiscuous_rx_cb(&sniffer);
  esp_wifi_set_promiscuous(true);
  esp_wifi_set_channel(CHANNEL, WIFI_SECOND_CHAN_NONE);
}

void loop() {
  Msg m;
  while (xQueueReceive(queue, &m, pdMS_TO_TICKS(5)) == pdTRUE) addSample(m);
  if (millis() - lastReport >= REPORT_MS) {
    lastReport = millis();
    report();
  }
}
