#!/usr/bin/env python3
"""
Позиціонування за силою сигналу ESP32 на Raspberry Pi Zero 2 W.

Приймач ESP32 надсилає по USB або UART рядки виду
    24:6F:28:A1:00:01, 640;
Програма усереднює силу сигналу від кожного передавача, переводить її у відстань,
обчислює положення та малює його на екрані.

Запуск:
    python3 locator.py                       — екран з мапою
    python3 locator.py --list                — зареєстровані передавачі
    python3 locator.py --add MAC X Y --name A — зареєструвати / оновити передавач
    python3 locator.py --remove MAC          — видалити передавач
    python3 locator.py --calibrate           — показувати силу сигналу для калібрування
Клавіші на екрані: F — повний екран, C — очистити слід, Q або Esc — вихід.
Незареєстрований передавач: торкніться його MAC у списку, потім місця на мапі.
"""
import argparse
import glob
import json
import math
import os
import re
import statistics
import sys
import threading
import time
from collections import deque

HERE = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(HERE, "config.json")

DEFAULT_CONFIG = {
    "serial_port": "auto",
    "baud": 115200,
    "area": {"width": 10, "height": 8},
    "signal": {"s_1m": 900, "s_10m": 600},
    "window_sec": 1.5,
    "smoothing": 0.35,
    "fullscreen": False,
    "transmitters": [],
}


# ---------------------------------------------------------------- конфігурація
def norm_mac(s):
    """Повертає MAC у вигляді AA:BB:CC:DD:EE:FF або None, якщо формат неправильний."""
    s = str(s).strip()
    if not re.fullmatch(r"[0-9A-Fa-f:\-.\s]+", s):
        return None
    h = re.sub(r"[^0-9A-Fa-f]", "", s).upper()
    if len(h) != 12:
        return None
    return ":".join(h[i:i + 2] for i in range(0, 12, 2))


def load_config(path):
    if not os.path.exists(path):
        save_config(path, DEFAULT_CONFIG)
    with open(path, encoding="utf-8") as f:
        cfg = json.load(f)
    merged = json.loads(json.dumps(DEFAULT_CONFIG))
    merged.update(cfg)
    for t in merged["transmitters"]:
        t["mac"] = norm_mac(t["mac"]) or t["mac"]
        t["x"], t["y"] = float(t["x"]), float(t["y"])
    return merged


def save_config(path, cfg):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


def fmt(v, n=2):
    return f"{v:.{n}f}".replace(".", ",")


# ---------------------------------------------------------------- вимірювання
class Readings:
    """Зберігає виміри кожного MAC за останні window секунд."""

    def __init__(self, window):
        self.window = window
        self.lock = threading.Lock()
        self.data = {}
        self.total = 0

    def add(self, mac, strength):
        with self.lock:
            self.data.setdefault(mac, deque()).append((time.monotonic(), strength))
            self.total += 1

    def snapshot(self):
        """{mac: (медіана сили, кількість вимірів, секунд від останнього)}"""
        now = time.monotonic()
        out = {}
        with self.lock:
            for mac, dq in self.data.items():
                while dq and now - dq[0][0] > self.window:
                    dq.popleft()
                if dq:
                    out[mac] = (statistics.median(v for _, v in dq), len(dq), now - dq[-1][0])
        return out


class SerialReader(threading.Thread):
    """Читає приймач у фоні, сам знаходить порт і перепідключається."""

    PART_RE = re.compile(r"([0-9A-Fa-f:\-]{12,17})\s*,\s*(\d+(?:\.\d+)?)")

    def __init__(self, port, baud, readings):
        super().__init__(daemon=True)
        self.port, self.baud, self.readings = port, baud, readings
        self.status = "Пошук приймача…"

    def candidates(self):
        if self.port != "auto":
            return [self.port]
        ports = sorted(glob.glob("/dev/ttyUSB*")) + sorted(glob.glob("/dev/ttyACM*"))
        if os.path.exists("/dev/serial0"):
            ports.append("/dev/serial0")
        return ports

    def run(self):
        try:
            import serial
        except ImportError:
            self.status = "Не встановлено pyserial: sudo apt install python3-serial"
            return
        while True:
            ports = self.candidates()
            if not ports:
                self.status = "Приймач не знайдено. Перевірте кабель."
                time.sleep(2)
                continue
            for p in ports:
                try:
                    with serial.Serial(p, self.baud, timeout=1) as ser:
                        self.status = f"Підключено: {p}"
                        last_data = time.monotonic()
                        while True:
                            raw = ser.readline()
                            if raw:
                                got = self.parse(raw.decode("utf-8", "ignore"))
                                if got:
                                    last_data = time.monotonic()
                            # в автоматичному режимі пробуємо інший порт, якщо цей мовчить
                            if self.port == "auto" and len(ports) > 1 and time.monotonic() - last_data > 5:
                                self.status = f"Немає даних на {p}, пробую інший порт…"
                                break
                except (serial.SerialException, OSError) as e:
                    self.status = f"Помилка порту {p}: {e}"
                    time.sleep(1)

    def parse(self, line):
        got = False
        for part in line.split(";"):
            m = self.PART_RE.search(part)
            if not m:
                continue
            mac = norm_mac(m.group(1))
            if mac:
                self.readings.add(mac, min(1000.0, max(0.0, float(m.group(2)))))
                got = True
        return got


# ---------------------------------------------------------------- обчислення
def strength_to_distance(s, cfg):
    s1, s10 = cfg["signal"]["s_1m"], cfg["signal"]["s_10m"]
    return 10 ** ((s1 - s) / max(1.0, s1 - s10))


def solve(pts):
    """pts: [(x, y, d)]. Зважений метод найменших квадратів (Левенберг–Марквардт).
    Повертає (x, y, rms) — rms показує, наскільки виміри узгоджуються між собою."""
    if not pts:
        return None

    def w(d):
        return 1.0 / max(d, 0.3) ** 2

    sw = sum(w(d) for _, _, d in pts)
    x = sum(w(d) * px for px, _, d in pts) / sw
    y = sum(w(d) * py for _, py, d in pts) / sw

    def cost(cx, cy):
        return sum(w(d) * (math.hypot(cx - px, cy - py) - d) ** 2 for px, py, d in pts)

    if len(pts) > 1:
        c, lam = cost(x, y), 1e-3
        for _ in range(80):
            a = b = cc = g1 = g2 = 0.0
            for px, py, d in pts:
                dx, dy = x - px, y - py
                r = math.hypot(dx, dy) or 1e-6
                wi, res, jx, jy = w(d), r - d, dx / r, dy / r
                a += wi * jx * jx; b += wi * jx * jy; cc += wi * jy * jy
                g1 += wi * jx * res; g2 += wi * jy * res
            A, C = a * (1 + lam) + 1e-9, cc * (1 + lam) + 1e-9
            det = A * C - b * b
            if abs(det) < 1e-14:
                break
            sx, sy = -(C * g1 - b * g2) / det, -(A * g2 - b * g1) / det
            nc = cost(x + sx, y + sy)
            if nc < c:
                x, y, c, lam = x + sx, y + sy, nc, lam * 0.3
                if math.hypot(sx, sy) < 1e-4:
                    break
            else:
                lam *= 10
                if lam > 1e9:
                    break
    rms = math.sqrt(sum((math.hypot(x - px, y - py) - d) ** 2 for px, py, d in pts) / len(pts))
    return x, y, rms


class Locator:
    """Об’єднує виміри, розв’язок і згладжування."""

    def __init__(self, cfg, readings):
        self.cfg, self.readings = cfg, readings
        self.pos = None      # згладжене положення (x, y)
        self.rms = None
        self.rows = []       # стан кожного передавача для екрана
        self.unknown = []
        self.heard = 0

    def update(self):
        snap = self.readings.snapshot()
        known = {t["mac"] for t in self.cfg["transmitters"]}
        pts, rows = [], []
        for t in self.cfg["transmitters"]:
            r = snap.get(t["mac"])
            if r and r[0] > 0:
                d = strength_to_distance(r[0], self.cfg)
                pts.append((t["x"], t["y"], d))
                rows.append((t, r[0], d, r[1]))
            else:
                rows.append((t, None, None, 0))
        self.rows, self.heard = rows, len(pts)
        self.unknown = sorted(
            ((m, v[0], strength_to_distance(v[0], self.cfg), v[1]) for m, v in snap.items() if m not in known),
            key=lambda u: -u[1])
        res = solve(pts)
        if res is None:
            self.pos, self.rms = None, None
            return
        x, y, self.rms = res
        a = float(self.cfg["smoothing"])
        if self.pos is None:
            self.pos = (x, y)
        else:
            self.pos = (self.pos[0] + a * (x - self.pos[0]), self.pos[1] + a * (y - self.pos[1]))


# ---------------------------------------------------------------- екран
BG = (14, 21, 34)
PAPER = (22, 32, 50)
GRID = (31, 44, 65)
MAJOR = (46, 62, 88)
INK = (227, 233, 240)
MUTED = (150, 165, 184)
TX = (63, 196, 204)
EST = (255, 111, 156)
WARN = (240, 179, 90)


def mix(c1, c2, t):
    return tuple(int(a + (b - a) * t) for a, b in zip(c1, c2))


def run_gui(cfg, cfg_path):
    import pygame

    readings = Readings(cfg["window_sec"])
    reader = SerialReader(cfg["serial_port"], cfg["baud"], readings)
    reader.start()
    loc = Locator(cfg, readings)

    pygame.display.init()   # без звуку: аудіо не потрібне
    pygame.font.init()
    fullscreen = bool(cfg["fullscreen"])

    def open_window():
        if fullscreen:
            return pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
        return pygame.display.set_mode((960, 560), pygame.RESIZABLE)

    open_window()
    pygame.display.set_caption("Позиціонування ESP32")

    def font(size, bold=False):
        return pygame.font.SysFont("dejavusans,freesans,liberationsans", size, bold=bold)

    f_big, f_mid, f_txt, f_small = font(26, True), font(19, True), font(16), font(13)
    clock = pygame.time.Clock()
    trail = deque(maxlen=80)
    last_calc = 0.0
    rate, rate_t, rate_n = 0.0, time.monotonic(), readings.total
    selected = None          # MAC незареєстрованого передавача, який зараз розміщуємо
    unknown_rects = []       # області рядків списку для натискання
    geo = {}                 # геометрія мапи з попереднього кадру
    msg, msg_t = "", 0.0

    def text(surf, s, f, color, pos, anchor="topleft"):
        img = f.render(s, True, color)
        rect = img.get_rect(**{anchor: pos})
        surf.blit(img, rect)
        return rect

    def dashed_circle(surf, color, c, r, dash=7):
        r = min(r, 4000)
        n = max(16, int(2 * math.pi * r / dash))
        n -= n % 2
        for i in range(0, n, 2):
            a1, a2 = 2 * math.pi * i / n, 2 * math.pi * (i + 1) / n
            pygame.draw.line(surf, color, (c[0] + r * math.cos(a1), c[1] + r * math.sin(a1)),
                             (c[0] + r * math.cos(a2), c[1] + r * math.sin(a2)), 1)

    while True:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                return
            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_ESCAPE and selected:
                    selected = None
                elif e.key in (pygame.K_ESCAPE, pygame.K_q):
                    return
                if e.key == pygame.K_f:
                    fullscreen = not fullscreen
                    open_window()
                if e.key == pygame.K_c:
                    trail.clear()
            if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1 and geo:
                hit = next((mac for mac, r in unknown_rects if r.collidepoint(e.pos)), None)
                if hit:
                    selected = None if selected == hit else hit
                elif selected and geo["map"].collidepoint(e.pos):
                    wx = (e.pos[0] - geo["ox"]) / geo["scale"]
                    wy = (geo["oy"] - e.pos[1]) / geo["scale"]
                    if 0 <= wx <= geo["aw"] and 0 <= wy <= geo["ah"]:
                        wx, wy = round(wx, 1), round(wy, 1)
                        used = {t.get("name") for t in cfg["transmitters"]}
                        name = next((chr(c) for c in range(65, 91) if chr(c) not in used),
                                    str(len(cfg["transmitters"]) + 1))
                        cfg["transmitters"].append({"name": name, "mac": selected, "x": wx, "y": wy})
                        save_config(cfg_path, cfg)
                        msg, msg_t = f"Зареєстровано {name}: {selected}  ({fmt(wx, 1)}; {fmt(wy, 1)} м)", time.monotonic()
                        selected = None
                        last_calc = 0.0

        now = time.monotonic()
        if now - last_calc >= 0.2:
            last_calc = now
            loc.update()
            if loc.pos:
                trail.append(loc.pos)
        if now - rate_t >= 1.0:
            rate = (readings.total - rate_n) / (now - rate_t)
            rate_t, rate_n = now, readings.total

        screen = pygame.display.get_surface()
        W, H = screen.get_size()
        screen.fill(BG)

        # --- геометрія мапи
        panel_w = max(260, min(340, int(W * 0.36)))
        if W < 640:                      # вузький екран: панель знизу
            map_rect = pygame.Rect(0, 0, W, int(H * 0.58))
            panel = pygame.Rect(0, map_rect.bottom, W, H - map_rect.bottom)
        else:
            map_rect = pygame.Rect(0, 0, W - panel_w, H)
            panel = pygame.Rect(map_rect.right, 0, panel_w, H)

        aw, ah = float(cfg["area"]["width"]), float(cfg["area"]["height"])
        pad = 34
        scale = min((map_rect.w - 2 * pad) / aw, (map_rect.h - 2 * pad) / ah)
        ox = map_rect.x + (map_rect.w - aw * scale) / 2
        oy = map_rect.y + (map_rect.h + ah * scale) / 2

        def P(x, y):
            return int(ox + x * scale), int(oy - y * scale)

        geo = {"map": map_rect, "ox": ox, "oy": oy, "scale": scale, "aw": aw, "ah": ah}

        x0, y0 = P(0, ah)
        pygame.draw.rect(screen, PAPER, (x0, y0, int(aw * scale), int(ah * scale)))
        step = 1 if scale >= 12 else (5 if scale >= 3 else 10)
        major = 5 if step == 1 else step * 2
        gx = 0.0
        while gx <= aw + 1e-9:
            col = MAJOR if round(gx) % major == 0 else GRID
            pygame.draw.line(screen, col, P(gx, 0), P(gx, ah))
            if round(gx) % major == 0:
                text(screen, str(int(gx)), f_small, MUTED, (P(gx, 0)[0], P(gx, 0)[1] + 5), "midtop")
            gx += step
        gy = 0.0
        while gy <= ah + 1e-9:
            col = MAJOR if round(gy) % major == 0 else GRID
            pygame.draw.line(screen, col, P(0, gy), P(aw, gy))
            if round(gy) % major == 0 and gy > 0:
                text(screen, str(int(gy)), f_small, MUTED, (P(0, gy)[0] - 6, P(0, gy)[1]), "midright")
            gy += step
        text(screen, "м", f_small, MUTED, (P(aw, 0)[0] + 16, P(aw, 0)[1] + 5))

        # --- кола відстаней, слід, передавачі, положення
        for t, s, d, _ in loc.rows:
            if d is not None:
                dashed_circle(screen, mix(PAPER, TX, 0.55), P(t["x"], t["y"]), int(d * scale))
        for i, p in enumerate(trail):
            pygame.draw.circle(screen, mix(PAPER, EST, 0.1 + 0.4 * i / len(trail)), P(*p), 3)
        for t, s, d, _ in loc.rows:
            c = P(t["x"], t["y"])
            pygame.draw.circle(screen, TX if s is not None else mix(PAPER, TX, 0.35), c, 9)
            pygame.draw.circle(screen, PAPER, c, 9, 2)
            label = f"{t.get('name') or t['mac'][-5:]}  {int(s) if s is not None else 'немає'}"
            right = c[0] > map_rect.right - 120
            text(screen, label, f_txt, INK, (c[0] + (-14 if right else 14), c[1]),
                 "midright" if right else "midleft")
        if loc.pos:   # маркер не виходить за межі мапи, точні числа — на панелі
            c = P(min(aw, max(0.0, loc.pos[0])), min(ah, max(0.0, loc.pos[1])))
            pygame.draw.circle(screen, EST, c, 14, 3)
            pygame.draw.line(screen, EST, (c[0] - 20, c[1]), (c[0] + 20, c[1]), 2)
            pygame.draw.line(screen, EST, (c[0], c[1] - 20), (c[0], c[1] + 20), 2)

        if selected:
            text(screen, f"Клацніть на мапі, де стоїть {selected}   (Esc — скасувати)", f_txt, EST,
                 (map_rect.x + 16, map_rect.y + 6))
        elif msg and now - msg_t < 5:
            text(screen, msg, f_txt, TX, (map_rect.x + 16, map_rect.y + 6))

        # --- панель
        pygame.draw.rect(screen, PAPER, panel)
        x, y = panel.x + 18, panel.y + 16
        text(screen, "Положення приймача", f_txt, MUTED, (x, y)); y += 24
        if loc.pos:
            text(screen, f"x = {fmt(loc.pos[0])} м", f_big, EST, (x, y)); y += 32
            text(screen, f"y = {fmt(loc.pos[1])} м", f_big, EST, (x, y)); y += 34
            text(screen, f"Узгодженість вимірів: ±{fmt(loc.rms, 1)} м", f_small, MUTED, (x, y)); y += 22
        else:
            text(screen, "невідоме", f_big, MUTED, (x, y)); y += 40
        if loc.heard < 3:
            text(screen, f"Чути {loc.heard} з {len(cfg['transmitters'])} передавачів", f_small, WARN, (x, y))
            y += 18
            text(screen, "Для точного положення потрібно 3.", f_small, WARN, (x, y))
            y += 22
        y += 10
        text(screen, "Передавачі", f_mid, INK, (x, y)); y += 28
        for t, s, d, n in loc.rows:
            name = t.get("name") or "—"
            text(screen, f"{name}  {t['mac']}", f_small, INK, (x, y)); y += 17
            if s is None:
                text(screen, "немає сигналу", f_small, WARN, (x, y))
            else:
                text(screen, f"сила {int(s)}   {fmt(d, 1)} м   вимірів: {n}", f_small, MUTED, (x, y))
            y += 24
        unknown_rects = []
        if loc.unknown:
            y += 4
            text(screen, f"Незареєстровані ({len(loc.unknown)}):", f_small, WARN, (x, y)); y += 20
            limit = max(1, (panel.bottom - 80 - y) // 36)
            for mac, s, d, n in loc.unknown[:limit]:
                row = pygame.Rect(panel.x + 10, y - 3, panel.w - 20, 34)
                if mac == selected:
                    pygame.draw.rect(screen, mix(PAPER, EST, 0.3), row, border_radius=5)
                elif row.collidepoint(pygame.mouse.get_pos()):
                    pygame.draw.rect(screen, mix(PAPER, INK, 0.08), row, border_radius=5)
                text(screen, mac, f_small, INK, (x, y)); y += 15
                text(screen, f"сила {int(s)}   ~{fmt(d, 1)} м", f_small, MUTED, (x, y)); y += 21
                unknown_rects.append((mac, row))
            if not selected:
                text(screen, "Торкніться MAC, щоб розмістити на мапі", f_small, MUTED, (x, y + 2))
        by = panel.bottom - 16
        text(screen, "F — повний екран   C — очистити слід   Q — вихід", f_small, MUTED, (x, by), "bottomleft")
        text(screen, f"{reader.status}   {rate:.0f} пак./с", f_small, MUTED, (x, by - 20), "bottomleft")

        pygame.display.flip()
        clock.tick(30)


# ---------------------------------------------------------------- команди
def calibrate(cfg):
    readings = Readings(3.0)
    reader = SerialReader(cfg["serial_port"], cfg["baud"], readings)
    reader.start()
    names = {t["mac"]: t.get("name", "") for t in cfg["transmitters"]}
    print("Поставте приймач на 1 м від передавача і запишіть силу як s_1m,")
    print("потім на 10 м — як s_10m. Ctrl+C — вихід.\n")
    try:
        while True:
            time.sleep(1)
            snap = readings.snapshot()
            print(f"[{reader.status}]")
            for mac, (s, n, _) in sorted(snap.items()):
                print(f"  {names.get(mac, '?'):>3}  {mac}  медіана {s:6.1f}  (вимірів: {n})")
            print()
    except KeyboardInterrupt:
        pass


def main():
    ap = argparse.ArgumentParser(description="Позиціонування за силою сигналу ESP32")
    ap.add_argument("--config", default=CONFIG_PATH, help="шлях до config.json")
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--add", nargs=3, metavar=("MAC", "X", "Y"), help="зареєструвати або оновити передавач")
    g.add_argument("--remove", metavar="MAC", help="видалити передавач")
    g.add_argument("--list", action="store_true", help="показати передавачі")
    g.add_argument("--calibrate", action="store_true", help="режим калібрування")
    ap.add_argument("--name", help="назва передавача для --add")
    ap.add_argument("--port", help="порт приймача, наприклад /dev/ttyUSB0 або /dev/serial0")
    args = ap.parse_args()

    cfg = load_config(args.config)
    if args.port:
        cfg["serial_port"] = args.port

    if args.add:
        mac = norm_mac(args.add[0])
        if not mac:
            sys.exit("Неправильний MAC. Приклад: 24:6F:28:A1:00:05")
        try:
            x, y = float(args.add[1].replace(",", ".")), float(args.add[2].replace(",", "."))
        except ValueError:
            sys.exit("Координати мають бути числами, наприклад 2.5")
        tx = next((t for t in cfg["transmitters"] if t["mac"] == mac), None)
        if tx:
            tx.update(x=x, y=y)
            if args.name:
                tx["name"] = args.name
            print(f"Оновлено {mac} -> ({x}; {y})")
        else:
            cfg["transmitters"].append({"name": args.name or chr(65 + len(cfg["transmitters"])),
                                        "mac": mac, "x": x, "y": y})
            print(f"Зареєстровано {mac} -> ({x}; {y})")
        save_config(args.config, cfg)
    elif args.remove:
        mac = norm_mac(args.remove)
        before = len(cfg["transmitters"])
        cfg["transmitters"] = [t for t in cfg["transmitters"] if t["mac"] != mac]
        save_config(args.config, cfg)
        print("Видалено" if len(cfg["transmitters"]) < before else "Такого MAC немає в списку")
    elif args.list:
        for t in cfg["transmitters"]:
            print(f"{t.get('name', ''):>3}  {t['mac']}  x={t['x']}  y={t['y']}")
        if not cfg["transmitters"]:
            print("Список порожній. Додайте: locator.py --add MAC X Y")
    elif args.calibrate:
        calibrate(cfg)
    else:
        run_gui(cfg, args.config)


if __name__ == "__main__":
    main()
